import tkinter as tk
import cv2
from PIL import Image, ImageTk

# Nhóm 4 AI1708, Ngọc Ân, Hoàng Anh, Minh Thông, Hoàng Việt, Minh, Nam

img = cv2.imread('image.jpg')
gray_img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
haar_cascade = cv2.CascadeClassifier('haarcascade_frontalface_default.xml')
meomeo = tk.Tk()


def display_image(window, img, row=2, column=1):  # format cv2.imread
    ga = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    # print(img)
    img1 = Image.fromarray(ga)
    img_resized1 = img1.resize((530, 400))  # new width & height
    # print(img_resized)
    img1 = ImageTk.PhotoImage(img_resized1)
    label = tk.Label(window, image=img1)  # using Button
    label.grid(row=row, column=column)
    label.image = img1  # keep a reference! by attaching it to a widget attribute
    label['image'] = img1  # Show Image


def haar_cascade_function(window, gray, image, haar_cascade):
    faces_rect = haar_cascade.detectMultiScale(
        gray, scaleFactor=1.2, minNeighbors=5, minSize=(30,30))
    print("Found {0} faces!".format(len(faces_rect)))
    for (x, y, w, h) in faces_rect:
        cv2.rectangle(image, (x, y), (x + w, y + h), (0, 255, 0), thickness=2)
    display_image(window, image, 2, 2)


meomeo.geometry("1100x1000")  # Size of the window
meomeo.title('Workshop 7')
b1 = tk.Button(meomeo, text='Show image',
               width=20, command=lambda: display_image(meomeo, img))
b2 = tk.Button(meomeo, text="Function 1: Haar Cascade",
               command=lambda: haar_cascade_function(meomeo, gray_img, img, haar_cascade))

### pack
# base.pack()
# w.pack()
b1.grid(row=1, column=1)
b2.grid(row=1, column=2)

### die
if __name__ == "__main__":
    meomeo.mainloop()
